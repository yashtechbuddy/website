<?php include("includes/header.php");

	require("includes/function.php");
	require("language/language.php");

 
	$cat_qry="SELECT * FROM image_cat ORDER BY title";
	$cat_result=mysqli_query($mysqli,$cat_qry); 
	
  $qry="SELECT * FROM tbl_post_gallery where id='".$_GET['edit_id']."'";
  $result=mysqli_query($mysqli,$qry);
  $row=mysqli_fetch_assoc($result);
	if(isset($_POST['submit']) and isset($_GET['add']))
	{
		
		//$cat_id=$_POST['cat_id'];
		//$qry11=mysqli_query($mysqli,'SELECT * FROM tbl_image_category WHERE id='.$cat_id.'');
		//$row11=mysqli_fetch_assoc($qry11);
		//$cat_title=$row11['title'];	
		
		//$count = count($_FILES['image']['name']);
		//for($i=0;$i<$count;$i++)
		//{ 
				
			$image="";
			if($_FILES['image']['name']!="")
			{	
				$image="Category-".rand(0,99999)."_".$_FILES['image']['name'];
				$tpath1='images/image_gallery/'.$image; 			 
				move_uploaded_file($_FILES["image"]["tmp_name"], $tpath1);
			}
			
			$file="";
			
			if($_FILES['file']['name']!="")
			{	
				$file="brochuer-".rand(0,99999)."_".$_FILES['file']['name'];
				$tpath1='images/image_gallery/'.$file; 			 
				move_uploaded_file($_FILES["file"]["tmp_name"], $tpath1);
			}
			/*COUNT LAST INSERTED POSITION NO */
			//$qry_order="SELECT * FROM tbl_post_gallery order by position_order ASC";
			//$result_order=mysqli_query($mysqli,$qry_order); 				
			//$position_order=mysqli_num_rows($result_order);  
			//$position_order=$position_order+1;
				
	     
			$data = array( 		
	
			'category_id'  => $_POST['cat_id'],
			'image'  =>  $image,
			'client_id' => $_POST['client'],
			'alt_tag'  =>  $_POST['alt_tag'],
			'link'  =>  $_POST['link'],
			'broch_link'  => $file
			//'position_order' => $position_order
			
			);		
			echo $data;

			$qry1 = Insert('tbl_post_gallery ',$data);	
			echo $qry1;
 	 		

			$_SESSION['msg']="10";
			header( "Location:manage_image_post.php");
			exit;	

		 
	}
	
	  
?>
<div class="breadcrumbbar">
   <div class="row align-items-center">
      <div class="col-md-8 col-lg-8">
         <h2 class="page-title"><?php if(isset($_GET['edit_id'])){?>Edit<?php }else{?>Add<?php }?> Image Gallery</h2>
      </div>
   </div>
</div>
                <?php if(isset($_SESSION['msg'])){?>
		    
			 <div class="alert alert-success alert-dismissible fade show" role="alert">
				<strong><?php echo $client_lang[$_SESSION['msg']]; ?> </strong>
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>              
			</div>  
			<?php unset($_SESSION['msg']);}?>
            <!-- End Breadcrumbbar -->
		<div class="contentbar">
                <!-- Start row -->
                <div class="row">
	 <!-- Start col -->
                    <div class="col-lg-12">
                        <div class="card m-b-30">
                            <div class="card-body">
								<form action="" name="editprofile" method="post" enctype="multipart/form-data">
								
									<input  type="hidden" name="edit_id" value="<?php echo $_GET['edit_id'];?>" />	
	 
									<div class="form-group row">
										<label class="col-sm-3 col-form-label">Category :-</label>
										<div class="col-sm-9">
											<select name="cat_id" class="form-control" id="formControlSelect" required>
												<option value="">--Select Category--</option>
												<?php
													while($cat_row=mysqli_fetch_array($cat_result))
													{
												?>          						 
													<option value="<?php echo $cat_row['id'];?>"><?php echo $cat_row['title'];?></option>	          							 
												<?php
												}
												?>
											</select>
										</div>
									</div>
				  
									<div class="form-group row">
										<label class="col-sm-3 col-form-label">Client :-</label>
										<div class="col-sm-9">
											<select name="client" class="form-control" id="formControlSelect" >
												<option value="">--Select Client--</option>
												<?php						
													$data_qry="SELECT * FROM tbl_client ORDER BY position_order";
													$data_result=mysqli_query($mysqli,$data_qry); 
													while($data_row=mysqli_fetch_array($data_result))
													{
												?>          						 
												<option value="<?php echo $data_row['id'];?>" <?php if($data_row['id']==$row['client_id']){?>selected<?php }?>><?php echo $data_row['name'];?></option>		 
												<?php
													}
												?>	
											</select>
										</div>
									</div>
				  
									<div class="form-group row">
										<label class="col-sm-3 col-form-label">Gallery Image :-</label>
											<div class="col-sm-9">
												<div class="fileupload_block">
													<input type="file" name="image" value="" id="fileupload" >
													<img type="image" style="width: 90px; height:auto;margin-bottom:10px;" src="assets/images/add-image.png" alt="image" />
					   
													<input type="text" name="alt_tag" id="alt_tag"  placeholder="Enter Image Alternate text" title="Enter Image Alternate text here !" value="<?php if(isset($_GET['edit_id'])){echo $row['alt_tag'];}?>" class="form-control" />
							
												</div>
											</div>
									</div>

									<div class="form-group row">
                    <label class="col-sm-3 col-form-label">Website Link :-</label>
                    <div class="col-sm-9">
                      <input type="text" name="link" value="<?php if(isset($_GET['edit_id'])){echo $row['link'];}?>" class="form-control" >
                    </div>
                  </div> 


					

                                   <div class="form-group row">
										<label class="col-sm-3 col-form-label">Broucher Upload :-</label>
											<div class="col-sm-9">
												<div class="fileupload_block">
													<input type="file" name="file" >
							
												</div>
											</div>
									</div>
				  
									 <?php //include_once('seo.php'); ?>
                                    <div class="form-group row row row">
                                        <div class="col-sm-10">
                                            <button type="submit" name="submit" class="btn btn-primary"><i class="feather icon-send mr-2"></i>Submit</button>
                                        </div>
                                    </div>
									<?php echo $qry1;?>
                                </form>
                            </div>
                        </div>
                    </div> 
                    <!-- End col -->
				</div>
			</div>

<!-- End Contentbar -->
<?php 
   include("includes/footer.php");
   ?>    
</div>
<!-- End Footerbar -->
</div>
<!-- End Rightbar -->
</div>
</body>
</html>